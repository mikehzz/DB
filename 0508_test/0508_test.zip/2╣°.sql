--[����2]

SELECT *
FROM board_99
;

INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (1,'����1','����1',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (2,'����2','����2',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (3,'����3','����3',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (4,'����4','����4',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (5,'����5','����5',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (6,'����6','����6',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (7,'����7','����7',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (8,'����8','����8',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (9,'����9','����9',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (10,'����10','����10',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (11,'����11','����11',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (12,'����12','����12',10,0,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (13,'����13','����13',20,1,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (14,'����14','����14',20,1,'20230508','pcwk','20230508','pcwk');
INSERT INTO board_99(seq, title,contents,div,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
       VALUES (15,'����15','����15',20,1,'20230508','pcwk','20230508','pcwk');

SELECT *
FROM board_99
;
